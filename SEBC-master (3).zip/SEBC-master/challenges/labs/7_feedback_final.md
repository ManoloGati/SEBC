Please use spaces below to answer the following questions:


How many times have you installed a Hadoop cluster (any kind) before this week?
```

```

What was the most familiar technical subject for you this week?
```

```

What was the most difficult technical subject for you this week?
```

```

Which subject that we covered did you learn the most from?
```

```

Which subject was least useful to you?
```

```

If you could add one subject to the class, what would it be?
```

```

How much time do you think you will need to be able to install a cluster by yourself (no help, no mentoring)?
```

```

Thank you and safe travels.

Michael (mfe@cloudera.com) & Carlo (cpiva@cloudera.com)
